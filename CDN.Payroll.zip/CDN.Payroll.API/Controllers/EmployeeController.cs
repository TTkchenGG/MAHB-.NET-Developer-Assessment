using CDN.Payroll.Application.DTOs;
using CDN.Payroll.Application.Interfaces;
using CDN.Payroll.Application.Services;
using CDN.Payroll.Domain.Entities;
using Microsoft.AspNetCore.Mvc;

namespace CDN.Payroll.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class EmployeesController : ControllerBase
{
    private readonly IEmployeeRepository _repository;

    public EmployeesController(IEmployeeRepository repository)
    {
        _repository = repository;
    }

    [HttpPost]
    public async Task<IActionResult> Create(
        CreateEmployeeRequest request)
    {
        var employee = new Employee
        {
            Id = Guid.NewGuid(),
            EmployeeName = request.EmployeeName,
            EmployeeNumber =
                EmployeeNumberGenerator.Generate(
                    request.EmployeeName,
                    request.DateOfBirth),

            NationalIdentificationNumber =
                request.NationalIdentificationNumber,

            ContactNumber = request.ContactNumber,

            Address = request.Address,

            DateOfBirth = request.DateOfBirth,

            DailyRate = request.DailyRate,

            IsArchived = false,

            WorkingDays = request.WorkingDays,

            Skillsets = request.Skillsets
        };

        await _repository.CreateAsync(employee);

        await _repository.AddWorkingDaysAsync(employee.Id, request.WorkingDays);

        await _repository.AddSkillsetsAsync(employee.Id, request.Skillsets);

        return Ok(employee);

    }

    [HttpGet]
    public async Task<IActionResult> GetAll(
        [FromQuery] string? search)
    {
        if (!string.IsNullOrWhiteSpace(search))
        {
            var result =
                await _repository.SearchAsync(search);

            return Ok(result);
        }

        var employees =
            await _repository.GetAllAsync();

        return Ok(employees);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(Guid id)
    {
        var employee =
            await _repository.GetByIdAsync(id);

        if (employee == null)
            return NotFound();

        return Ok(employee);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(
        Guid id,
        [FromBody] CreateEmployeeRequest request)
    {
        var employee =
            await _repository.GetByIdAsync(id);

        if (employee == null)
            return NotFound();

        employee.EmployeeName = request.EmployeeName;
        employee.NationalIdentificationNumber =
            request.NationalIdentificationNumber;
        employee.ContactNumber = request.ContactNumber;
        employee.Address = request.Address;
        employee.DateOfBirth = request.DateOfBirth;
        employee.DailyRate = request.DailyRate;
        employee.WorkingDays = request.WorkingDays;
        employee.Skillsets = request.Skillsets;
        await _repository.UpdateAsync(employee);
        await _repository.UpdateWorkingDaysAsync(employee.Id, request.WorkingDays);
        await _repository.UpdateSkillSetsAsync(employee.Id, request.Skillsets);
        return Ok(employee);
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(Guid id)
    {
        var employee = await _repository.GetByIdAsync(id);

        if (employee == null)
        {
            return NotFound(new
            {
                Message = "Employee not found."
            });
        }

        await _repository.DeleteAsync(id);

        return Ok(new
        {
            Message = "Employee record has been deleted successfully."
        });
    }

    [HttpPut("{id}/archive")]
    public async Task<IActionResult> Archive(Guid id)
    {
        await _repository.ArchiveAsync(id);

        return Ok();
    }

    [HttpPut("{id}/unarchive")]
    public async Task<IActionResult> Unarchive(Guid id)
    {
        await _repository.UnarchiveAsync(id);

        return Ok();
    }
}