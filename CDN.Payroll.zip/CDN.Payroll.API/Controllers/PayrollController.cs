using CDN.Payroll.Application.DTOs;
using CDN.Payroll.Application.Interfaces;
using CDN.Payroll.Application.Services;
using Microsoft.AspNetCore.Mvc;

namespace CDN.Payroll.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PayrollController : ControllerBase
{
    private readonly IEmployeeRepository _repository;
    private readonly PayrollService _payrollService;

    public PayrollController(
        IEmployeeRepository repository,
        PayrollService payrollService)
    {
        _repository = repository;
        _payrollService = payrollService;
    }

    [HttpPost("calculate")]
    public async Task<IActionResult> Calculate(
        [FromBody] CalculatePayrollRequest request)
    {
        var employee =
            await _repository.GetByIdAsync(
                request.EmployeeId);

        if (employee == null)
            return NotFound();

        var totalPay =
            _payrollService.Calculate(
                employee,
                request.StartDate,
                request.EndDate,
                out var workingDayCount,
                out var birthdayBonusApplied);

        var response =
            new PayrollResponse
            {
                EmployeeNumber =
                    employee.EmployeeNumber,

                WorkingDayCount =
                    workingDayCount,

                BirthdayBonusApplied =
                    birthdayBonusApplied,

                TotalPay =
                    totalPay
            };

        return Ok(response);
    }
}