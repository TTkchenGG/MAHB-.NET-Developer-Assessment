namespace CDN.Payroll.Domain.Entities;

public class EmployeeWorkingDay
{
    public Guid EmployeeId { get; set; }

    public DayOfWeek DayOfWeek { get; set; }
}