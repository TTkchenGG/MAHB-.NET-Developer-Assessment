namespace CDN.Payroll.Domain.Entities;

public class Employee
{
    public Guid Id { get; set; }

    public string EmployeeNumber { get; set; } = string.Empty;

    public string EmployeeName { get; set; } = string.Empty;

    public string NationalIdentificationNumber { get; set; } = string.Empty;

    public string ContactNumber { get; set; } = string.Empty;

    public string Address { get; set; } = string.Empty;

    public DateTime DateOfBirth { get; set; }

    public decimal DailyRate { get; set; }

    public bool IsArchived { get; set; }

    public List<string> Skillsets { get; set; } = [];

    public List<DayOfWeek> WorkingDays { get; set; } = [];
}