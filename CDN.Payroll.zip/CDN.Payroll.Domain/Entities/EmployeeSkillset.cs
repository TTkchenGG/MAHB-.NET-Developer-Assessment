namespace CDN.Payroll.Domain.Entities;

public class EmployeeSkillset
{
    public Guid EmployeeId { get; set; }

    public string Skillset { get; set; }
}