using CDN.Payroll.Domain.Entities;

namespace CDN.Payroll.Application.Services;

public class PayrollService
{
    public decimal Calculate(
        Employee employee,
        DateTime startDate,
        DateTime endDate,
        out int workingDayCount,
        out bool birthdayBonusApplied)
    {
        workingDayCount = 0;
        birthdayBonusApplied = false;

        decimal totalPay = 0;

        for (var date = startDate.Date;
             date <= endDate.Date;
             date = date.AddDays(1))
        {
            if (employee.WorkingDays.Contains(date.DayOfWeek))
            {
                workingDayCount++;

                totalPay += employee.DailyRate * 2;
            }
        }

        var birthdayThisYear =
            new DateTime(
                startDate.Year,
                employee.DateOfBirth.Month,
                employee.DateOfBirth.Day);

        if (birthdayThisYear >= startDate &&
            birthdayThisYear <= endDate)
        {
            birthdayBonusApplied = true;

            totalPay += employee.DailyRate;
        }

        return totalPay;
    }
}