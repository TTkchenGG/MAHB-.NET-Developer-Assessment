namespace CDN.Payroll.Application.Services;

public static class EmployeeNumberGenerator
{
    public static string Generate(
        string employeeName,
        DateTime dateOfBirth)
    {
        var prefix = employeeName
            .Trim()
            .Substring(0, 3)
            .ToUpper();

        var randomNumber =
            Random.Shared.Next(0, 99999);

        return
            $"{prefix}-{randomNumber:D5}-{dateOfBirth:ddMMMyyyy}"
            .ToUpper();
    }
}