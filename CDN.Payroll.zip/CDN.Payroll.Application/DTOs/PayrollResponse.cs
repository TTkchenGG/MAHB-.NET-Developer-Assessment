namespace CDN.Payroll.Application.DTOs;

public class PayrollResponse
{
    public string EmployeeNumber { get; set; } = string.Empty;

    public int WorkingDayCount { get; set; }

    public bool BirthdayBonusApplied { get; set; }

    public decimal TotalPay { get; set; }
}