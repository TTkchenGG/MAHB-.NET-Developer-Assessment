namespace CDN.Payroll.Application.DTOs;

public class CalculatePayrollRequest
{
    public Guid EmployeeId { get; set; }

    public DateTime StartDate { get; set; }

    public DateTime EndDate { get; set; }
}