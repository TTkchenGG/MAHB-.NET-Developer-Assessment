using CDN.Payroll.Application.DTOs;
using FluentValidation;

namespace CDN.Payroll.Application.Validators;

public class CreateEmployeeRequestValidator
    : AbstractValidator<CreateEmployeeRequest>
{
    public CreateEmployeeRequestValidator()
    {
        RuleFor(x => x.EmployeeName)
            .NotEmpty()
            .MaximumLength(200);

        RuleFor(x => x.NationalIdentificationNumber)
            .NotEmpty();

        RuleFor(x => x.DateOfBirth)
            .LessThan(DateTime.Today);

        RuleFor(x => x.DailyRate)
            .GreaterThan(0);

        RuleFor(x => x.WorkingDays)
           .NotEmpty()
           .WithMessage("At least one working day is required.");

        RuleFor(x => x.WorkingDays)
            .Must(days => days.Distinct().Count() == days.Count)
            .WithMessage("Duplicate working days are not allowed.");

        RuleFor(x => x.Skillsets)
          .NotEmpty()
           .WithMessage("At least one skill is required.");

    }
}