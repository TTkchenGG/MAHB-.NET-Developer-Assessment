using CDN.Payroll.Domain.Entities;

namespace CDN.Payroll.Application.Interfaces;

public interface IEmployeeRepository
{
    Task<Guid> CreateAsync(Employee employee);

    Task<Employee?> GetByIdAsync(Guid id);

    Task<IEnumerable<Employee>> GetAllAsync();

    Task<IEnumerable<Employee>> SearchAsync(string search);

    Task UpdateAsync(Employee employee);

    Task DeleteAsync(Guid id);

    Task ArchiveAsync(Guid id);

    Task UnarchiveAsync(Guid id);

    Task AddWorkingDaysAsync(Guid employeeId, List<DayOfWeek> workingDays);

    Task AddSkillsetsAsync(Guid employeeId,List<string> skillSets);

    Task UpdateWorkingDaysAsync(Guid employeeId, List<DayOfWeek> workingDays);

    Task UpdateSkillSetsAsync(Guid employeeId,List<string> skillSets);
} 
