CREATE TABLE Employees
(
    Id UNIQUEIDENTIFIER PRIMARY KEY,
    EmployeeNumber VARCHAR(30) NOT NULL UNIQUE,
    EmployeeName VARCHAR(200) NOT NULL,
    NationalIdentificationNumber VARCHAR(50) NOT NULL,
    ContactNumber VARCHAR(50),
    Address VARCHAR(500),
    DateOfBirth DATE NOT NULL,
    DailyRate DECIMAL(18,2) NOT NULL,
    IsArchived BIT NOT NULL DEFAULT 0,
    CreatedDate DATETIME2 NOT NULL DEFAULT GETDATE()
);

CREATE TABLE Skillsets
(
    Id UNIQUEIDENTIFIER PRIMARY KEY,
    SkillName VARCHAR(100) NOT NULL
);

CREATE TABLE EmployeeWorkingDays
(
    EmployeeId UNIQUEIDENTIFIER NOT NULL,
    DayOfWeek INT NOT NULL,

    PRIMARY KEY(EmployeeId, DayOfWeek),

    FOREIGN KEY(EmployeeId)
        REFERENCES Employees(Id)
);