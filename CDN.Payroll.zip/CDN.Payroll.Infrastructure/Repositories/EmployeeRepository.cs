using CDN.Payroll.Application.Interfaces;
using CDN.Payroll.Domain.Entities;
using CDN.Payroll.Infrastructure.Persistence;
using Dapper;

namespace CDN.Payroll.Infrastructure.Repositories;

public class EmployeeRepository : IEmployeeRepository
{
    private readonly SqlConnectionFactory _factory;

    public EmployeeRepository(SqlConnectionFactory factory)
    {
        _factory = factory;
    }

    public async Task<Guid> CreateAsync(Employee employee)
    {
        const string sql = """
        INSERT INTO Employees
        (
            Id,
            EmployeeNumber,
            EmployeeName,
            NationalIdentificationNumber,
            ContactNumber,
            Address,
            DateOfBirth,
            DailyRate,
            IsArchived
        )
        VALUES
        (
            @Id,
            @EmployeeNumber,
            @EmployeeName,
            @NationalIdentificationNumber,
            @ContactNumber,
            @Address,
            @DateOfBirth,
            @DailyRate,
            @IsArchived
        )
        """;

        using var connection = _factory.CreateConnection();

        await connection.ExecuteAsync(sql, employee);

        return employee.Id;
    }

    public async Task<IEnumerable<Employee>> GetAllAsync()
    {
        var sql = @"
    SELECT
        Id,
        EmployeeNumber,
        EmployeeName,
        NationalIdentificationNumber,
        ContactNumber,
        Address,
        DateOfBirth,
        DailyRate,
        IsArchived
    FROM Employees
    ORDER BY EmployeeName";

        using var connection = _factory.CreateConnection();

        var employees = (await connection.QueryAsync<Employee>(sql)).ToList();

        foreach (var employee in employees)
        {
            var workingDays =
                await connection.QueryAsync<int>(
                    @"SELECT DayOfWeek
                    FROM EmployeeWorkingDays
                    WHERE EmployeeId = @EmployeeId",
                    new { EmployeeId = employee.Id });

            employee.WorkingDays = workingDays
                .Select(x => (DayOfWeek)x)
                .ToList();

            var skillsets =
                await connection.QueryAsync<string>(
                    @"SELECT SkillName
                    FROM EmployeeSkillsets
                    WHERE EmployeeId = @EmployeeId",
                    new { EmployeeId = employee.Id });

            employee.Skillsets = skillsets.ToList();
        }

        return employees;

    }

    public async Task<IEnumerable<Employee>> SearchAsync(string search)
    {
        var sql = @"
            SELECT *
            FROM Employees
            WHERE EmployeeNumber LIKE @Search
            OR EmployeeName LIKE @Search
            ORDER BY EmployeeName";

        using var connection = _factory.CreateConnection();

        var employees = (
            await connection.QueryAsync<Employee>(
                sql,
                new
                {
                    Search = $"%{search}%"
                }))
            .ToList();

        foreach (var employee in employees)
        {
            var workingDays =
                await connection.QueryAsync<int>(
                    @"SELECT DayOfWeek
                    FROM EmployeeWorkingDays
                    WHERE EmployeeId = @EmployeeId",
                    new { EmployeeId = employee.Id });

            employee.WorkingDays = workingDays
                .Select(x => (DayOfWeek)x)
                .ToList();

            var skillsets =
                await connection.QueryAsync<string>(
                    @"SELECT SkillName
                    FROM EmployeeSkillsets
                    WHERE EmployeeId = @EmployeeId",
                    new { EmployeeId = employee.Id });

            employee.Skillsets = skillsets.ToList();
        }

        return employees;
    }

    public async Task<Employee?> GetByIdAsync(Guid id)
    {
        using var connection =
            _factory.CreateConnection();

        var employee = await connection
            .QueryFirstOrDefaultAsync<Employee>(
            @"SELECT *
          FROM Employees
          WHERE Id = @Id",
            new { Id = id });

        if (employee == null)
            return null;

        var workingDays =
            await connection.QueryAsync<int>(
            @"SELECT DayOfWeek
          FROM EmployeeWorkingDays
          WHERE EmployeeId = @EmployeeId",
            new { EmployeeId = id });

        employee.WorkingDays =
            workingDays
                .Select(x => (DayOfWeek)x)
                .ToList();

        var skills =
            await connection.QueryAsync<string>(
                @"SELECT SkillName
                FROM EmployeeSkillsets
                WHERE EmployeeId = @EmployeeId",
                new { EmployeeId = id });

        employee.Skillsets = skills.ToList();

        return employee;
    }
    public async Task UpdateAsync(Employee employee)
    {
        var sql = @"
    UPDATE Employees
    SET
        EmployeeName = @EmployeeName,
        NationalIdentificationNumber = @NationalIdentificationNumber,
        ContactNumber = @ContactNumber,
        Address = @Address,
        DateOfBirth = @DateOfBirth,
        DailyRate = @DailyRate
    WHERE Id = @Id";

        using var connection = _factory.CreateConnection();

        await connection.ExecuteAsync(sql, employee);
    }

    public async Task UpdateWorkingDaysAsync(
    Guid employeeId,
    List<DayOfWeek> workingDays)
    {
        using var connection = _factory.CreateConnection();

        await connection.ExecuteAsync(
            @"DELETE FROM EmployeeWorkingDays
          WHERE EmployeeId = @EmployeeId",
            new { EmployeeId = employeeId });

        foreach (var day in workingDays)
        {
            await connection.ExecuteAsync(
                @"INSERT INTO EmployeeWorkingDays
              (
                  EmployeeId,
                  DayOfWeek
              )
              VALUES
              (
                  @EmployeeId,
                  @DayOfWeek
              )",
                new
                {
                    EmployeeId = employeeId,
                    DayOfWeek = (int)day
                });
        }
    }

    public async Task UpdateSkillSetsAsync(
    Guid employeeId,
    List<string> skillSets)
    {
        using var connection = _factory.CreateConnection();

        await connection.ExecuteAsync(
            @"DELETE FROM EmployeeSkillsets
          WHERE EmployeeId = @EmployeeId",
            new { EmployeeId = employeeId });

        foreach (var skillset in skillSets)
        {
            await connection.ExecuteAsync(
                @"INSERT INTO EmployeeSkillsets
              (
                  EmployeeId,
                  SkillName
              )
              VALUES
              (
                  @EmployeeId,
                  @SkillSet
              )",
                new
                {
                    EmployeeId = employeeId,
                    SkillSet = skillset
                });
        }
    }

    public async Task DeleteAsync(Guid id)
    {
        var sql = @"
        DELETE FROM EmployeeWorkingDays
        WHERE EmployeeId = @Id;

        DELETE FROM EmployeeSkillsets
        WHERE EmployeeId = @Id;

        DELETE FROM EmployeeSkillsets
        WHERE EmployeeId = @Id;

        DELETE FROM Employees
        WHERE Id = @Id;";

        using var connection = _factory.CreateConnection();

        await connection.ExecuteAsync(sql, new { Id = id });
    }

    public async Task ArchiveAsync(Guid id)
    {
        var sql = @"
        UPDATE Employees
        SET IsArchived = 1
        WHERE Id = @Id";

        using var connection = _factory.CreateConnection();

        await connection.ExecuteAsync(sql, new { Id = id });
    }

    public async Task UnarchiveAsync(Guid id)
    {
        var sql = @"
        UPDATE Employees
        SET IsArchived = 0
        WHERE Id = @Id";

        using var connection = _factory.CreateConnection();

        await connection.ExecuteAsync(sql, new { Id = id });
    }

    public async Task AddWorkingDaysAsync(
    Guid employeeId,
    List<DayOfWeek> workingDays)
    {
        var sql = @"
        INSERT INTO EmployeeWorkingDays
        (
            EmployeeId,
            DayOfWeek
        )
        VALUES
        (
            @EmployeeId,
            @DayOfWeek
        )";

        using var connection = _factory.CreateConnection();

        foreach (var day in workingDays)
        {
            await connection.ExecuteAsync(
                sql,
                new
                {
                    EmployeeId = employeeId,
                    DayOfWeek = (int)day
                });
        }
    }

    public async Task AddSkillsetsAsync(
    Guid employeeId,
    List<string> skillsets)
    {
        var sql = @"
        INSERT INTO EmployeeSkillsets
        (
            EmployeeId,
            SkillName
        )
        VALUES
        (
            @EmployeeId,
            @SkillName
        )";

        using var connection = _factory.CreateConnection();

        foreach (var skill in skillsets)
        {
            await connection.ExecuteAsync(
                sql,
                new
                {
                    EmployeeId = employeeId,
                    SkillName = skill
                });
        }
    }
}
