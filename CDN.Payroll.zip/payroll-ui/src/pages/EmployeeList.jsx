import { useEffect, useState } from "react";
import api from "../api/employeeApi";
import { useNavigate } from "react-router-dom";

function EmployeeList() {

    const [employees, setEmployees] = useState([]);
    const [search, setSearch] = useState("");
    const navigate = useNavigate();
    const loadEmployees = async () => {

        const response = await api.get(
            `/employees?search=${search}`
        );

        setEmployees(response.data);
    };
    const archiveEmployee = async (id) => {
        if (!window.confirm(
            "Archive this employee?"
        ))
        {
            return;
        }
        await api.put(
            `/employees/${id}/archive`
        );
        loadEmployees();
    };

    const unarchiveEmployee = async (id) => {
        await api.put(
            `/employees/${id}/unarchive`
        );
        loadEmployees();
    };

    const deleteEmployee = async (id) => {
        if (!window.confirm(
            "Delete this employee?"
        ))
        {
            return;
        }
        await api.delete(`/employees/${id}`);

        alert("Employee deleted successfully.");

        loadEmployees();
    };

    useEffect(() => {
        loadEmployees();
    }, []);

    return (
        <div className="container mt-4">

    <div className="card shadow-sm">
        <div className="card-body">

            <div className="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2 className="mb-0"><b>Employees</b></h2>
                    <small className="text-muted">
                        Manage employee records
                    </small>
                </div>

                <button
                    className="btn btn-success"
                    onClick={() => navigate("/create")}
                >
                    Add Employee
                </button>
            </div>

            <div className="d-flex justify-content-between align-items-center mb-3">
                <div className="col-md-6 p-0">
                    <div className="input-group">

                        <input
                            type="text"
                            className="form-control"
                            placeholder="Search employee..."
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                            onKeyDown={(e) => {
                                if (e.key === "Enter") {
                                    loadEmployees();
                                }
                            }}
                        />

                        <button
                            className="btn btn-primary"
                            onClick={loadEmployees}
                        >
                            Search
                        </button>

                    </div>
                </div>

                <span className="text-muted me-2">
                Total Records: {employees.length}
                </span>
            </div>
            <div className="card shadow">
                <div className="table-responsive"
                style={{
                maxHeight: "500px",
                overflowY: "auto"
                }}
                >

                    <table className="table table-bordered table-striped table-hover">

                        <thead className="table-dark"
                        style={{
                                position: "sticky",
                                top: 0,
                                zIndex: 1
                                }}
                        >
                            <tr>
                                <th>Employee Number</th>
                                <th>Employee Name</th>
                                <th>Daily Rate</th>
                                <th>Archived</th>
                                <th width="150">Action</th>
                                <th>Payroll</th>
                            </tr>
                        </thead>

                        <tbody>

                            {employees.length === 0 ? (

                                <tr>
                                    <td
                                        colSpan="5"
                                        className="text-center text-muted"
                                    >
                                        No records found.
                                    </td>
                                </tr>

                            ) : (

                                employees.map(employee => (
                                    <tr key={employee.id}>

                                        <td>
                                            {employee.employeeNumber}
                                        </td>

                                        <td>
                                            {employee.employeeName}
                                        </td>

                                        <td>
                                            RM {Number(employee.dailyRate)
                                                .toFixed(2)}
                                        </td>

                                        <td>
                                            <span
                                                className={
                                                    employee.isArchived
                                                        ? "badge bg-danger"
                                                        : "badge bg-success"
                                                }
                                            >
                                                {
                                                    employee.isArchived
                                                        ? "Archived"
                                                        : "Active"
                                                }
                                            </span>
                                        </td>

                                    <td>
                                            <div className="d-flex gap-2">

                                                <button
                                                    className="btn btn-warning btn-sm shadow action-button"
                                                    onClick={() =>
                                                        navigate(`/edit/${employee.id}`)
                                                    }
                                                >
                                                    Edit
                                                </button>

                                                {
                                                    employee.isArchived
                                                        ? (
                                                            <button
                                                                className="btn btn-success btn-sm shadow-sm"
                                                                onClick={() =>
                                                                    unarchiveEmployee(employee.id)
                                                                }
                                                            >
                                                                Unarchive
                                                            </button>
                                                        )
                                                        : (
                                                            <button
                                                                className="btn btn-secondary btn-sm shadow-sm"
                                                                onClick={() =>
                                                                    archiveEmployee(employee.id)
                                                                }
                                                            >
                                                                Archive
                                                            </button>
                                                        )
                                                }

                                                <button
                                                    className="btn btn-danger btn-sm shadow-sm"
                                                    onClick={() =>
                                                        deleteEmployee(employee.id)
                                                    }
                                                >
                                                    Delete
                                                </button>

                                            </div>

                                        </td>

                                        <td>
                                            <button
                                                className="btn btn-info btn-sm shadow-sm"
                                                onClick={() =>
                                                    navigate(
                                                        `/payroll/${employee.id}`
                                                    )
                                                }
                                            >
                                                Calculate
                                            </button>
                                        </td>

                                    </tr>
                                ))

                            )}

                        </tbody>

                    </table>

                </div>
            </div>
        </div>
    </div>

</div>
    );
}

export default EmployeeList;