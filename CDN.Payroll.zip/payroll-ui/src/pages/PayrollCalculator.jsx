import { useEffect, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import api from "../api/employeeApi";

function PayrollCalculator() {

    const resultRef = useRef(null);
    const { id } = useParams();

    const navigate = useNavigate();

    const [startDate, setStartDate] = useState("");
    const [endDate, setEndDate] = useState("");

    const [result, setResult] = useState(null);

    const [employee, setEmployee] = useState(null);

    const dayNames = {
        7: "SUN",
        1: "MON",
        2: "TUE",
        3: "WED",
        4: "THU",
        5: "FRI",
        6: "SAT"
    };

    const calculatePayroll = async () => {

        if (!startDate || !endDate)
        {
            alert(
                "Please select start date and end date."
            );
            return;
        }

        if (startDate > endDate)
        {
            alert(
                "Start Date cannot be later than End Date."
            );
            return;
        }

        const response =
            await api.post(
                "/payroll/calculate",
                {
                    employeeId: id,
                    startDate,
                    endDate
                });

        setResult(response.data);
        setTimeout(() => {
            resultRef.current?.scrollIntoView({
            behavior: "smooth",
            block: "start"
            });
        }, 100);
    };

    useEffect(() => {

        if (id) {
            loadEmployee();
        }

    }, [id]);

    const loadEmployee = async () => {

        const response =
            await api.get(`/employees/${id}`);

        setEmployee(response.data);
    };

    return (
        
        <div className="container mt-4">
            {/* Employee Information */}

            {
                employee && (

                    <div className="card shadow mb-4">

                        <div className="card-header">
                            <h3 className="mb-0">
                                Employee Information
                            </h3>
                        </div>

                        <div className="card-body">

                            <div className="row">

                                <div className="col-md-6 mb-3">
                                    <strong>
                                        Employee Number:
                                    </strong>
                                    <br />
                                    {employee.employeeNumber}
                                </div>

                                <div className="col-md-6 mb-3">
                                    <strong>
                                        Employee Name:
                                    </strong>
                                    <br />
                                    {employee.employeeName}
                                </div>

                                <div className="col-md-6 mb-3">
                                    <strong>
                                        Date Of Birth:
                                    </strong>
                                    <br />
                                    {
                                        new Date(
                                            employee.dateOfBirth
                                        )
                                            .toLocaleDateString(
                                                "en-GB"
                                            )
                                    }
                                </div>

                                <div className="col-md-6 mb-3">
                                    <strong>
                                        Daily Rate:
                                    </strong>
                                    <br />
                                    RM{" "}
                                    {
                                        Number(
                                            employee.dailyRate
                                        )
                                            .toFixed(2)
                                    }
                                </div>

                                <div className="col-md-6 mb-3">
                                    <strong>
                                        Working Days:
                                    </strong>
                                    <br />
                                    {
                                        employee.workingDays?.map(day => (

                                            <span
                                                key={day}
                                                className="badge bg-primary me-2"
                                            >
                                                {dayNames[day]}
                                            </span>

                                        ))
                                    }
                                </div>

                                <div className="col-md-6 mb-3">
                                    <strong>
                                        Skillsets:
                                    </strong>
                                    <br />
                                    {
                                        employee.skillsets
                                            ?.join(", ")
                                    }
                                </div>

                            </div>

                        </div>

                    </div>

                )
            }

            {/* Payroll Form */}
            <div className="card shadow">

                <div className="card-header">
                    <h3 className="mb-0">
                        Payroll Calculation
                    </h3>
                </div>

                <div className="card-body">

                    <div className="row">

                        <div className="col-md-6 mb-3">

                            <label className="form-label">
                                Start Date
                            </label>

                            <input
                                type="date"
                                className="form-control"
                                value={startDate}
                                onChange={(e) =>
                                    setStartDate(
                                        e.target.value
                                    )
                                }
                            />

                        </div>

                        <div className="col-md-6 mb-3">

                            <label className="form-label">
                                End Date
                            </label>

                            <input
                                type="date"
                                className="form-control"
                                value={endDate}
                                onChange={(e) =>
                                    setEndDate(
                                        e.target.value
                                    )
                                }
                            />

                        </div>

                    </div>

                    <div className="d-flex gap-2 justify-content-center">

                        <button
                            className="btn btn-primary"
                            onClick={calculatePayroll}
                        >
                            Calculate
                        </button>

                        <button
                            className="btn btn-secondary"
                            onClick={() => navigate("/")}
                        >
                            Back
                        </button>

                    </div>

                    {
                        result && (

                            <div
                                ref={resultRef}
                                className="card mt-4 border-success border-3 shadow-lg"
                            >

                                <div className="card-body">

                                    <h5>
                                        Payroll Result
                                    </h5>

                                    <p>
                                        <strong>
                                            Employee Number:
                                        </strong>{" "}
                                        {
                                            result.employeeNumber
                                        }
                                    </p>

                                    <p>
                                        <strong>
                                            Working Day Count:
                                        </strong>{" "}
                                        {
                                            result.workingDayCount
                                        }
                                    </p>

                                    <p>
                                        <strong>
                                            Birthday Bonus:
                                        </strong>{" "}
                                        {
                                            result.birthdayBonusApplied
                                                ? "Yes"
                                                : "No"
                                        }
                                    </p>

                                    <p>
                                        <strong>
                                            Total Pay:
                                        </strong>{" "}
                                        RM{" "}
                                        {
                                            Number(
                                                result.totalPay
                                            ).toFixed(2)
                                        }
                                    </p>

                                </div>

                            </div>

                        )
                    }

                </div>

            </div>

        </div>
    );
}

export default PayrollCalculator;