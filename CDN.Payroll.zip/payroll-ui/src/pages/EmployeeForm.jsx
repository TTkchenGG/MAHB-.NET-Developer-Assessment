import { useEffect, useState } from "react";
import api from "../api/employeeApi";
import { useNavigate, useParams } from "react-router-dom";

function EmployeeForm() {

    const navigate = useNavigate();
    const { id } = useParams();

    const [employeeName, setEmployeeName] = useState("");
    const [nationalIdentificationNumber, setNationalIdentificationNumber] = useState("");
    const [contactNumber, setContactNumber] = useState("");
    const [address, setAddress] = useState("");
    const [dateOfBirth, setDateOfBirth] = useState("");
    const [dailyRate, setDailyRate] = useState("");
    const [workingDays, setWorkingDays] = useState([]);
    const [skillsets, setSkillsets] = useState("");
    const [errors, setErrors] = useState({});
    


    const handleWorkingDayChange = (day) => {

        if (workingDays.includes(day))
        {
            setWorkingDays(
                workingDays.filter(x => x !== day)
            );
        }
        else
        {
            setWorkingDays([
                ...workingDays,
                day
            ]);
        }
    };

    const validate = () => {

        const newErrors = {};

        if (!employeeName.trim())
        {
            newErrors.employeeName =
                "Employee Name is required";
        }
        else if (employeeName.trim().length < 3)
        {
            newErrors.employeeName =
            "Employee Name must be at least 3 characters.";
        }

        if (!nationalIdentificationNumber.trim())
        {
            newErrors.nationalIdentificationNumber =
                "National ID is required";
        }

        if (!dateOfBirth)
        {
            newErrors.dateOfBirth =
                "Date of Birth is required";
        }

        if (Number(dailyRate) <= 0)
        {
            newErrors.dailyRate =
                "Daily Rate must be greater than 0";
        }

        if (workingDays.length === 0)
        {
            newErrors.workingDays =
                "At least one working day is required";
        }

        const skills =
            skillsets
                .split(",")
                .map(x => x.trim())
                .filter(x => x !== "");

        if (skills.length === 0)
        {
            newErrors.skillsets =
                "At least one skillset is required";
        }

        setErrors(newErrors);

        return Object.keys(newErrors).length === 0;
    };

    const createEmployee = async () => {

        if (!validate())
            {
            return;
            }

        const request = {
            employeeName,
            nationalIdentificationNumber,
            contactNumber,
            address,
            dateOfBirth,
            dailyRate: Number(dailyRate),
            workingDays: workingDays,
            skillsets: skillsets.split(",").map(x => x.trim()).filter(x => x !== "")
        };

        if (id)
            {
                await api.put(
                    `/employees/${id}`,
                    request
                );

                alert(
                    "Employee updated successfully."
                );
            }
            else
            {
                await api.post(
                    "/employees",
                    request
                );

                alert(
                    "Employee created successfully."
                );
            }

        navigate("/");
    };

    const loadEmployee = async () => {

        const response =
            await api.get(`/employees/${id}`);

        const employee =
            response.data;

        setEmployeeName(employee.employeeName);

        setNationalIdentificationNumber(
            employee.nationalIdentificationNumber
        );

        setContactNumber(
            employee.contactNumber
        );

        setAddress(
            employee.address
        );

        setDateOfBirth(
            employee.dateOfBirth.split("T")[0]
        );

        setDailyRate(
            employee.dailyRate
        );

        setWorkingDays(
            employee.workingDays
        );

        setSkillsets(
            employee.skillsets.join(", ")
        );
    };


    useEffect(() => {

        if (id) {
            loadEmployee();
        }

    }, [id]);



    return (
        <div className="container mt-4">

            <div className="card shadow">

                <div className="card-header">
                    <h3 className="mb-0">
                        {
                            id
                                ? "Edit Employee"
                                : "Add Employee"
                        }
                    </h3>
                </div>

                <div className="card-body">

                    <div className="row">

                        <div className="col-md-6 mb-3">
                            <label className="form-label">Name</label>

                            <input
                                className="form-control"
                                value={employeeName}
                                onChange={(e) =>
                                    setEmployeeName(e.target.value)
                                }
                            />

                            {                            
                                errors.employeeName &&                                
                                (                                
                                <div className="text-danger mt-1">                                
                                    {errors.employeeName}                                
                                </div>                                
                                )
                            }
                        </div>

                        <div className="col-md-6 mb-3">
                            <label className="form-label">
                                National ID
                            </label>

                            <input
                                className="form-control"
                                value={nationalIdentificationNumber}
                                onChange={(e) =>
                                    setNationalIdentificationNumber(
                                        e.target.value
                                    )
                                }
                            />
                            {
                                errors.nationalIdentificationNumber &&
                                (
                                    <div className="text-danger mt-2">
                                        {errors.nationalIdentificationNumber}
                                    </div>
                                )
                            }
                        </div>

                        <div className="col-md-6 mb-3">
                            <label className="form-label">
                                Contact Number
                            </label>

                            <input
                                className="form-control"
                                value={contactNumber}
                                onChange={(e) =>
                                    setContactNumber(
                                        e.target.value
                                    )
                                }
                            />
                            {
                                errors.contactNumber &&
                                (
                                <div className="text-danger mt-1">
                                {errors.contactNumber}
                                </div>
                                )
                            }
                            
                        </div>

                        <div className="col-md-6 mb-3">
                            <label className="form-label">
                                Date Of Birth
                            </label>

                            <input
                                type="date"
                                className="form-control"
                                value={dateOfBirth}
                                onChange={(e) =>
                                    setDateOfBirth(
                                        e.target.value
                                    )
                                }
                            />
                            {
                                errors.dateOfBirth &&
                                (
                                <div className="text-danger mt-1">
                                {errors.dateOfBirth}
                                </div>
                                )
                            }
                        </div>

                        <div className="col-md-12 mb-3">
                            <label className="form-label">
                                Address
                            </label>

                            <input
                                className="form-control"
                                value={address}
                                onChange={(e) =>
                                    setAddress(
                                        e.target.value
                                    )
                                }
                            />
                            {
                                errors.address &&
                                (
                                <div className="text-danger mt-1">
                                {errors.address}
                                </div>
                                )
                            }
                        </div>

                        <div className="col-md-6 mb-3">
                            <label className="form-label">
                                Daily Rate
                            </label>

                            <input
                                type="number"
                                className="form-control"
                                value={dailyRate}
                                onChange={(e) =>
                                    setDailyRate(
                                        e.target.value
                                    )
                                }
                            />
                            {
                                errors.dailyRate &&
                                (
                                <div className="text-danger mt-1">
                                {errors.dailyRate}
                                </div>
                                )
                            }
                        </div>

                        <div className="col-md-6 mb-3">
                            <label className="form-label">
                                Skill Sets
                            </label>

                            <input
                                className="form-control"
                                placeholder="C#, React, SQL"
                                value={skillsets}
                                onChange={(e) =>
                                    setSkillsets(
                                        e.target.value
                                    )
                                }
                            />
                            {
                                errors.skillsets &&
                                (
                                <div className="text-danger mt-1">
                                {errors.skillsets}
                                </div>
                                )
                            }
                        </div>

                    </div>

                    <hr />

                    <div className="mb-3">

                        <label className="form-label fw-bold">
                            Working Days
                        </label>

                        <div className="d-flex flex-wrap justify-content-center gap-3 mt-2">

                            {[
                                { id: 1, name: "Monday" },
                                { id: 2, name: "Tuesday" },
                                { id: 3, name: "Wednesday" },
                                { id: 4, name: "Thursday" },
                                { id: 5, name: "Friday" },
                                { id: 6, name: "Saturday" },
                                { id: 7, name: "Sunday" }
                            ].map(day => (

                                <div
                                    key={day.id}
                                    className="form-check"
                                >

                                    <input
                                        className="form-check-input"
                                        type="checkbox"
                                        checked={workingDays.includes(day.id)}
                                        onChange={() =>
                                            handleWorkingDayChange(
                                                day.id
                                            )
                                        }
                                    />

                                    <label className="form-check-label">
                                        {day.name}
                                    </label>

                                </div>
                            ))}

                        </div>
                        {
                            errors.workingDays &&
                            (
                                <div className="text-danger mt-2">
                                    {errors.workingDays}
                                </div>
                            )
                        }

                    </div>

                    <div className="d-flex justify-content-center gap-2 mt-4">

                        <button
                            className="btn btn-primary"
                            onClick={createEmployee}
                        >
                            Save
                        </button>

                        <button
                            className="btn btn-secondary"
                            onClick={() => navigate("/")}
                        >
                            Cancel
                        </button>

                    </div>

                </div>

            </div>

        </div>
    );
}

export default EmployeeForm;