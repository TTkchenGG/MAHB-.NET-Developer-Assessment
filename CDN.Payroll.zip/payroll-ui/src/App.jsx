import { BrowserRouter, Routes, Route } from "react-router-dom";

import EmployeeList from "./pages/EmployeeList";
import EmployeeForm from "./pages/EmployeeForm";
import PayrollCalculator from "./pages/PayrollCalculator";

function App() {
    return (
        <BrowserRouter>
            <Routes>
                <Route path="/" element={<EmployeeList />} />
                <Route path="/create" element={<EmployeeForm />} />
                <Route path="/edit/:id" element={<EmployeeForm />}/>
                <Route path="/payroll/:id" element={<PayrollCalculator />}
/>
            </Routes>
        </BrowserRouter>
    );
}

export default App;