import axios from "axios";

const api = axios.create({
    baseURL: "http://localhost:5104/api"
});

export default api;