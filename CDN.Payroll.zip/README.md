# Payroll Management System

## Prerequisites

Please ensure the following are installed:

- .NET SDK
- SQL Server
- Node.js and npm

---

## Database Setup

1. Create a SQL Server database.
2. Run the provided SQL script in 'Database/Init.sql' to create the required tables.
3. Update the connection string in:

```text
CDN.Payroll.API/appsettings.json
```

Example:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Your SQL Server Connection String"
  }
}
```

---

## Running the Backend

Open a terminal in the solution folder and run:

```bash
dotnet restore
dotnet build
dotnet run --project CDN.Payroll.API
```

Swagger will be available at:

```
https://localhost:<port>/swagger
```

---

## Running the Frontend

Open a terminal in the React project folder:

```bash
cd payroll-ui
```

Install dependencies:

```bash
npm install
```

Run the application:

```bash
npm run dev
```

Open:

```text
http://localhost:5173
```

---

## Features

- Employee Management (Create, View, Update, Delete)
- Search Employee
- Archive / Unarchive Employee
- Working Days Management
- Skillsets Management
- Payroll Calculation
- Birthday Bonus Calculation
