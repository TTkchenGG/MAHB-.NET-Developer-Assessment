using CDN.Payroll.Application.Services;
using CDN.Payroll.Domain.Entities;
using FluentAssertions;

namespace CDN.Payroll.Tests;

public class PayrollServiceTests
{
[Fact]
public void Calculate_Should_Return_Normal_Pay()
{
    var employee = new Employee
    {
        DailyRate = 100,
        DateOfBirth = new DateTime(1994, 9, 10),
        WorkingDays = new()
        {
            DayOfWeek.Tuesday,
            DayOfWeek.Thursday
        }
    };

    var service = new PayrollService();

    var result = service.Calculate(
        employee,
        new DateTime(2025, 9, 1),
        new DateTime(2025, 9, 5),
        out var workingDays,
        out var birthdayBonus);

    result.Should().Be(400);

    birthdayBonus.Should().BeFalse();
}

[Fact]
public void Calculate_Should_Apply_Birthday_Bonus()
{
    var employee = new Employee
    {
        DailyRate = 100,
        DateOfBirth = new DateTime(1994, 9, 10),
        WorkingDays = new()
        {
            DayOfWeek.Tuesday,
            DayOfWeek.Thursday
        }
    };

    var service = new PayrollService();

    var result = service.Calculate(
        employee,
        new DateTime(2025, 9, 8),
        new DateTime(2025, 9, 12),
        out var workingDays,
        out var birthdayBonus);

    result.Should().Be(500);

    birthdayBonus.Should().BeTrue();
}
}