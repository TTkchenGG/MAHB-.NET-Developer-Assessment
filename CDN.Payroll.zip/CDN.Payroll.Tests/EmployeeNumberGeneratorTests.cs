using CDN.Payroll.Application.Services;
using FluentAssertions;

namespace CDN.Payroll.Tests;

public class EmployeeNumberGeneratorTests
{
    [Fact]
    public void Generate_Should_Return_Correct_Format()
    {
        // Arrange
        var name = "Razak bin Osman";
        var dob = new DateTime(1994, 1, 10);

        // Act
        var result = EmployeeNumberGenerator.Generate(name, dob);

        // Assert
        result.Should().StartWith("RAZ-");
        result.Should().EndWith("-10JAN1994");
    }
}